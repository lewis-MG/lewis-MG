package com.example.myapplication
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var inputNumber: EditText
    private lateinit var fromBaseSpinner: Spinner
    private lateinit var toBaseSpinner: Spinner
    private lateinit var convertButton: Button
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI elements
        inputNumber = findViewById(R.id.inputNumber)
        fromBaseSpinner = findViewById(R.id.fromBaseSpinner)
        toBaseSpinner = findViewById(R.id.toBaseSpinner)
        convertButton = findViewById(R.id.convertButton)
        resultTextView = findViewById(R.id.resultTextView)

        // Set up spinner adapters
        val adapter = ArrayAdapter.createFromResource(
            this, R.array.number_systems, android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        fromBaseSpinner.adapter = adapter
        toBaseSpinner.adapter = adapter

        // Set up button click listener
        convertButton.setOnClickListener {
            convertNumber()
        }
    }

    private fun convertNumber() {
        val input = inputNumber.text.toString()

        if (input.isEmpty()) {
            resultTextView.text = "Please enter a number"
            return
        }

        val fromBase = getBaseFromSpinner(fromBaseSpinner)
        val toBase = getBaseFromSpinner(toBaseSpinner)

        try {
            // Convert input number from the base specified by the user
            val number = input.toInt(fromBase)
            // Convert the number to the target base
            val result = number.toString(toBase).uppercase()
            resultTextView.text = "Result: $result"
        } catch (e: NumberFormatException) {
            resultTextView.text = "Invalid number format"
        }
    }

    // Helper function to get the base from the spinner selection
    private fun getBaseFromSpinner(spinner: Spinner): Int {
        return when (spinner.selectedItem.toString()) {
            "Binary" -> 2
            "Decimal" -> 10
            "Octal" -> 8
            "Hexadecimal" -> 16
            else -> 10
        }
    }
}





